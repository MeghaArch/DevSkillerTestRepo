package com.abnamro.test.Facade;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * Unit test for Facade.
 */
public class FacadeTest {
    /**
     * Test case for the facade.
     */
	@Test
    public void testFacade() {
		FacadeClass facade = new FacadeClass();
		
		assertEquals("SubSystem1", facade.getSubSystem1());
		assertEquals("SubSystem2", facade.getSubSystem2());
		assertEquals("SubSystemParent", facade.getParentSystem());
		
    }
}
