package com.abnamro.test.Facade;

public class SubSystemParent implements SystemInterface{

	public String getSystem() {
		// TODO Auto-generated method stub
		System.out.println("This is SubSystemParent");
		return "SubSystemParent";
	}

}
