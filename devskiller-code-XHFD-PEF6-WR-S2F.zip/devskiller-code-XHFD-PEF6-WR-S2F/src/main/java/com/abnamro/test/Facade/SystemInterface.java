package com.abnamro.test.Facade;

public interface SystemInterface {
	public String getSystem();
}
