package com.abnamro.test.Facade;

public class FacadeClass {
	private SubSystemParent parent;
	private SubSystem1 subSystem1;
	private SubSystem2 subSystem2;

	public FacadeClass() {
		parent = new SubSystemParent();
		subSystem1 = new SubSystem1();
		subSystem2 = new SubSystem2();
	}
	
	public String getParentSystem() {
		return parent.getSystem();
	}
	
	public String getSubSystem1() {
			return subSystem1.getSystem();	
		}
	
	public String getSubSystem2() {
		return subSystem2.getSystem();
	}
}
