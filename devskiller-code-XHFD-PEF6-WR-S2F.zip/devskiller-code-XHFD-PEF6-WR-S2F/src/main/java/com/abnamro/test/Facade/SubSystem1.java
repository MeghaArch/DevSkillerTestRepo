package com.abnamro.test.Facade;

/**
 * SubSystem 1.
 */
public class SubSystem1 extends SubSystemParent{
	public void doSomething() {
		System.out.println("This is SubSystem 1");
	}
	public String getSystem() {
		System.out.println("This is SubSystem 1");
		return "SubSystem1";
	}
}
