package com.abnamro.test.Facade;

/**
 * SubSystem 2.
 */
public class SubSystem2  extends SubSystemParent{
	public void doSomethingElse() {
		System.out.println("This is SubSystem 2");
	}
	public String getSystem() {
		System.out.println("This is SubSystem 2");
		return "SubSystem2";
	}
}
