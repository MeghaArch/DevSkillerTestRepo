package com.abnamro.test.Facade;

public class MainClass {
	public static void main(String[] args) {
		FacadeClass facade = new FacadeClass();
		facade.getParentSystem();
		facade.getSubSystem1();
		facade.getSubSystem2();
	}
	
}
